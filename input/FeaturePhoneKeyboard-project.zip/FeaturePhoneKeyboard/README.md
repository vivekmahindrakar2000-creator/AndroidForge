# Feature Phone Keyboard — prototype 0.1

A no-root Android prototype intended to run as the **lower app in Android split-screen**.
It is deliberately not a floating overlay: the goal is for Android's split-screen manager
to allocate the lower pane to this keyboard app, leaving the upper pane for another app.

## Important limitations

- This prototype does **not** force arbitrary apps into a top-half viewport by itself.
  The user must start Android split-screen and place the target app above this app.
- The keyboard panel stays visible as long as Android keeps this app in the lower split-screen pane.
  Android may exit split-screen for some system screens, camera flows, secure screens, or app transitions.
- Text insertion through Accessibility is experimental and app-dependent. If it cannot find a compatible
  editable field, the SEND button copies the text to the clipboard so it can be pasted manually.
- This is a prototype, not a polished production keyboard. Shift and symbol switching are placeholders.
- Accessibility permission is optional. It is powerful; enable it only if you are comfortable granting
  the app access to inspect and interact with screen content. This prototype processes text locally.

## Build an APK

This environment did not include the Android SDK, Android Gradle Plugin cache, or Android build tools,
so an APK could not be compiled or signed here. The source project is ready to open in Android Studio.

1. Install Android Studio on a computer.
2. Open this `FeaturePhoneKeyboard` folder as a project.
3. Let Android Studio install the requested Android SDK (compile SDK 35) and sync Gradle.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer it to your Realme and install it. You may need to allow installation from that file manager.

## Use on the Realme Narzo 50 Pro 5G

1. Install and open **Feature Phone Keyboard**.
2. Optional: tap **OPEN ACCESSIBILITY SETTINGS** and enable its input helper if you want to test direct text insertion.
3. Open Recent Apps.
4. Put your target app into split-screen in the upper pane.
5. Select **Feature Phone Keyboard** as the lower pane.
6. Resize the divider to approximately 50/50.

The keyboard is an ordinary app window in the lower pane, so it is not expected to disappear just because the upper app's text field loses focus.
