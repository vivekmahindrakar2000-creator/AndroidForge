package com.example.featurephonekeyboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val typed = StringBuilder()
    private lateinit var preview: TextView
    private lateinit var status: TextView

    private val rows = listOf(
        listOf("Q","W","E","R","T","Y","U","I","O","P"),
        listOf("A","S","D","F","G","H","J","K","L"),
        listOf("⇧","Z","X","C","V","B","N","M","⌫"),
        listOf("?123",",","SPACE",".","↵")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(27, 34, 44)
        window.navigationBarColor = Color.rgb(27, 34, 44)
        window.decorView.setBackgroundColor(Color.rgb(27, 34, 44))
        buildUi()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.rgb(27, 34, 44))
        }

        val heading = TextView(this).apply {
            text = "FEATURE PHONE KEYBOARD"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(8))
        }
        outer.addView(heading, matchWrap())

        preview = TextView(this).apply {
            text = "Your text will appear here"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(48, 58, 72))
            maxLines = 2
        }
        outer.addView(preview, LinearLayout.LayoutParams(-1, dp(52)))

        status = TextView(this).apply {
            text = "For best results, open this app in the BOTTOM split-screen pane."
            setTextColor(Color.LTGRAY)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        }
        outer.addView(status, matchWrap())

        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { key ->
                val button = Button(this).apply {
                    text = key
                    textSize = if (key.length > 1) 11f else 15f
                    isAllCaps = false
                    setTextColor(Color.WHITE)
                    setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        when (key) {
                            "SPACE", "↵", "?123" -> Color.rgb(78, 94, 116)
                            else -> Color.rgb(64, 77, 96)
                        }
                    ))
                    setOnClickListener { press(key) }
                }
                val weight = if (key == "SPACE") 4f else if (key == "?123" || key == "↵") 1.5f else 1f
                val lp = LinearLayout.LayoutParams(0, dp(48), weight).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                }
                line.addView(button, lp)
            }
            outer.addView(line, LinearLayout.LayoutParams(-1, dp(52)))
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(actionButton("SEND") { sendText() }, weighted())
        actions.addView(actionButton("COPY") { copyText() }, weighted())
        actions.addView(actionButton("CLEAR") {
            typed.clear()
            refresh()
        }, weighted())
        outer.addView(actions, LinearLayout.LayoutParams(-1, dp(48)))

        val help = TextView(this).apply {
            text = "Enable the input helper in Android Accessibility settings to try sending text to a compatible field in the upper app. If that fails, use COPY then paste."
            setTextColor(Color.LTGRAY)
            textSize = 10f
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        outer.addView(help, matchWrap())

        val enable = actionButton("OPEN ACCESSIBILITY SETTINGS") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        outer.addView(enable, LinearLayout.LayoutParams(-1, dp(44)))

        val scroll = ScrollView(this).apply { addView(outer) }
        setContentView(scroll)
    }

    private fun press(key: String) {
        when (key) {
            "⌫" -> if (typed.isNotEmpty()) typed.deleteCharAt(typed.length - 1)
            "SPACE" -> typed.append(' ')
            "↵" -> typed.append('\n')
            "⇧" -> { /* Uppercase layout is the default in this prototype. */ }
            "?123" -> status.text = "Number/symbol layout is planned for the next build."
            else -> typed.append(key.lowercase())
        }
        refresh()
    }

    private fun refresh() {
        preview.text = if (typed.isEmpty()) "Your text will appear here" else typed.toString()
    }

    private fun sendText() {
        val value = typed.toString()
        if (value.isEmpty()) return
        val service = KeyboardAccessibilityService.current
        val sent = service?.replaceFocusedText(value) == true
        if (sent) {
            Toast.makeText(this, "Sent to a compatible text field", Toast.LENGTH_SHORT).show()
        } else {
            copyText()
            Toast.makeText(this, "Couldn't reach a compatible field. Text copied; paste it in the upper app.", Toast.LENGTH_LONG).show()
        }
    }

    private fun copyText() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Keyboard text", typed.toString()))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 10f
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
        setMargins(dp(2), 0, dp(2), 0)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
