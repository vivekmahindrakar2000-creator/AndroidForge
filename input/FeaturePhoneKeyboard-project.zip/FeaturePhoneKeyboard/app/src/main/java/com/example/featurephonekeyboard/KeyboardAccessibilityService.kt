package com.example.featurephonekeyboard

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class KeyboardAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var current: KeyboardAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    fun replaceFocusedText(text: String): Boolean {
        // Search interactive windows because the keyboard app itself is the
        // foreground window while the user taps its keys in split-screen.
        for (window in windows) {
            val root = window.root ?: continue
            // Only target the actual input-focused node. Never guess at an
            // arbitrary editable field in another app.
            val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: continue
            if (!target.isEditable) continue
            val args = android.os.Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    text
                )
            }
            if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                return true
            }
        }
        return false
    }

    fun showStatus(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
